<?php

namespace app;

//Création de la classe PersonneManager
class PersonneManager{
    //l'attributs correspondant au point de connexion de la base de donnée
    private $db;
    //La construction autour de cet attribut
    public function __construct($db)
    {
        $this->db = $db;
    }

    //Ajouter une personne
    public function add(Personne $pers){
        //verifier que la personne n'existe pas

        $sql = 'INSERT INTO personne(nom, prenom) VALUES(:nom, :prenom)';

        $q = $this->db->prepare($sql);

        $q->bindValue(':nom', $pers->getNom());
        $q->bindValue(':prenom', $pers->getPrenom());

        $r=$q->execute();

        return $r;
    }

    //Récupérer toutes les personnes présentes dans la base de donnée sous forme de tableau
    public function getAll()
    {
        //renvoyer le tableau de toutes les personnes

        $data=array();

        $sql="select * from personne ";

        $res=$this->db->query($sql);


        $donnees=$res->fetchAll(\PDO::FETCH_ASSOC);

        foreach($donnees as $k=>$v){
            $data[]=new Personne($v);
        }

        return $data;
    }

    //Supprimer une personne
    public function delete(Personne $perso){
        //verifier que la personne n'existe pas

        $sql2 = "DELETE FROM personne WHERE '$this->nom = $nom'";
        $q2 = $this->db->prepare($sql2);
        $r2=$q2->execute();

        return $r2;
    }


}